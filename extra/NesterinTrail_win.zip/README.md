# NESTERIN TRAIL (Windows version)

This is the Windows version of the C64 text/graphic adventure game **Nesterin Trail**, by **Marco Giorgini** (@marcogiorgini).

The only difference between this and the C64 version is the graphics (same pictures, but with different colour resolution).


Press **ecape** to switch between fullscreen/windowed mode

Write **quit** in game parser to close the program

**save**/**load** commands write/read save file in program current folder


You can read more about it (including info on game settings, how to play and a full walkthrough) on its official itch.io page: https://marcogiorgini.itch.io/nesterin-trail